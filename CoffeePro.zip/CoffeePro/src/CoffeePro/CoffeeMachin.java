/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication8;

import java.sql.SQLException;

/**
 *
 * @author swaty
 */
public class CoffeeMachin {

    private WaterTank water;
    private BeansContnuor beans;
    private WasteTray waste;
    private Grinder grinder;
    private Logger logger;

    public CoffeeMachin(WaterTank water, BeansContnuor beans, WasteTray waste, Grinder grinder, Logger logger) {
        this.water = water;
        this.beans = beans;
        this.waste = waste;
        this.grinder = grinder;
        this.logger = logger;
    }


    public WaterTank getWater() {
        return water;
    }

    public void setWater(WaterTank water) {
        this.water = water;
    }

    public BeansContnuor getBeans() {
        return beans;
    }

    public void setBeans(BeansContnuor beans) {
        this.beans = beans;
    }

    public WasteTray getWaste() {
        return waste;
    }

    public void setWaste(WasteTray waste) {
        this.waste = waste;
    }

    public Grinder getGrinder() {
        return grinder;
    }

    public void setGrinder(Grinder grinder) {
        this.grinder = grinder;
    }

    public int getCounter() throws SQLException, ClassNotFoundException {
        return new BDLoger().CountCups();
    }

    public WaterTank watertankvalue() {
        return water;
    }

    public BeansContnuor beanscontnuor() {
        return beans;
    }

    public WasteTray wastetray() {
        return waste;
    }



    public void checkContent(int water, int beans) throws WaterException, BeansException {
        this.water.findWater(water);
        this.beans.findBeans(beans);
    }

    public void MakeCoffee(String coffeename, int wateramount, int beansamount, int grinder, int wasty) throws ClassNotFoundException, SQLException {
        this.grinder.grinder(grinder);
        this.water.drein(wateramount);
        this.beans.drein(beansamount);
        this.wastetray().setCapsity(this.wastetray().getCapsity() - wasty);
        logger.log(coffeename,water.getCapsity(),beans.getCapsity());
    }

}
