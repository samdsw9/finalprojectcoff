/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication8;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author fafan
 */
public class BDLoger implements Logger{
     private PreparedStatement statement;
    private final Connection conn;

    public BDLoger() throws SQLException {
        this.conn = DriverManager.getConnection("jdbc:mysql://localhost/Coffees", "root", "");
    }
    /**
     *
     * @param name
     * @param beans
     * @param water
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    @Override
            public void log(String name, int water, int beans) throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        String sql = "INSERT INTO coffee(coffeename,waterafter,beansafter) VALUES (?, ?, ?);";
        this.statement = conn.prepareStatement(sql);
        statement.setString(1, name);
        statement.setInt(2, water);
        statement.setInt(3,beans);
        statement.executeUpdate();
        if (statement != null) {
            statement.close();
        }
        
    }

    /**
     *
     * @return
     * @throws SQLException
     * @throws ClassNotFoundException
     */
    public int CountCups() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver");
        String query = "SELECT count(coffeename) AS cup FROM coffee ;";
        statement = conn.prepareStatement(query);
        ResultSet resultSet = statement.executeQuery(query);
        int count = 0;
        while (resultSet.next()) {
            count = resultSet.getInt("cup");
        }
        return count;
    }

   
    public int Water() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver");
        String query = "SELECT waterafter AS maxx FROM coffee where id =(SELECT MAX(id) from coffee);";
        statement = conn.prepareStatement(query);
        ResultSet resultSet = statement.executeQuery(query);
        int count = 0;
        while (resultSet.next()) {
            count = resultSet.getInt("maxx");
        }
        return count;
    }

    public int Beans() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver");
        String query = "SELECT coffeeafter AS maxx FROM coffee where id =(SELECT MAX(id) from coffee);";
        statement = conn.prepareStatement(query);
        ResultSet resultSet = statement.executeQuery(query);
        int count = 0;
        while (resultSet.next()) {
            count = resultSet.getInt("maxx");
        }
        return count;
    }
   
    
}
