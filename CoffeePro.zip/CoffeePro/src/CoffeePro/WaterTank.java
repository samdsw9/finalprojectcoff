/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication8;

import javax.swing.JOptionPane;

/**
 *
 * @author swaty
 */
public class WaterTank {
    private int capsity ;

    public WaterTank(int capsity) {
        this.capsity = capsity;
    }

   

    public int getCapsity() {
        return capsity;
    }

    public void setCapsity(int capsity) {
        this.capsity = capsity;
    }

    public void fill (int amount){
        capsity=capsity + amount;
        }
    public void drein(int amount){
       capsity -= amount ;
}

   public boolean findWater(int amount) throws WaterException {
        if (capsity <= amount) {
            throw new WaterException("the Water is embty");
        } else {
        }
        return true;
    }
    
}

