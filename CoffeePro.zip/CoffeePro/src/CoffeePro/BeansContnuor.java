/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication8;

import javax.swing.JOptionPane;

/**
 *
 * @author swaty
 */
public class BeansContnuor {
    private int capacety ;

    public BeansContnuor(int capacety) {
        this.capacety = capacety;
    }


    public int getCapsity() {
        return capacety;
    }

    public void setCabacety(int capacety) {
        this.capacety = capacety;
    }
     public void fill (int amount){
        capacety=amount;}
    public void drein(int amount){
       capacety -= amount ;
    }
       public boolean findBeans(int amount) throws BeansException {
        if (capacety <= amount) {
            throw new BeansException("the beans is embty");
        }
        return true;
    }
}
